# student-management-system
Proyek akhir mata kuliah Struktur Data

## anggota kelompok
| Nama                      | NIM               |
| ------------------------- | ----------------- |
| Ester Bina Br. Damanik    | G6401211030       |
| Lutfiah Nursabiliyanti    | G6401211041       |
| Muhammad Tegar Santoso    | G6401211086       |

## compile and run
- compile:

    `$ g++ *.cpp -o app`

    or

    `$ g++ app.cpp avl.cpp DLL.cpp hashmap.cpp model.cpp myVector.cpp node.cpp -o app`

- run

    `$ ./app`
    
    or

    `$ app.exe`